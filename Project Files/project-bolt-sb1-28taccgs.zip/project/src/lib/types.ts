export type View =
  | { name: 'home' }
  | { name: 'details'; movieId: string }
  | { name: 'seats'; movieId: string; theater: string; showtime: string }
  | { name: 'checkout'; movieId: string; theater: string; showtime: string; seats: string[]; total: number }
  | { name: 'dashboard' }
  | { name: 'admin' }
  | { name: 'auth' };

export const THEATERS = [
  'Grand Auditorium',
  'Skyline Cinema',
  'The Velvet Reel',
];

export const SHOWTIMES = ['10:00 AM', '1:15 PM', '7:45 PM'];

export const SEAT_PRICE = 10;
