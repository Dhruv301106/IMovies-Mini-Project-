const API_BASE = '/api';

export interface Movie {
  id: string;
  title: string;
  genre: string;
  duration: string;
  image: string;
  desc: string;
  createdAt: string;
  updatedAt: string;
}

export interface Booking {
  id: string;
  movieId: string;
  movieTitle: string;
  movieImage: string | null;
  theater: string;
  showtime: string;
  seats: string[];
  total: number;
  date: string;
}

const FIXED_DATE = '2026-10-20T00:00:00.000Z';

export const MOCK_MOVIES: Movie[] = [
  {
    id: 'mock-1',
    title: 'Nebula Drift',
    genre: 'Sci-Fi',
    duration: '2h 18m',
    image: 'https://images.pexels.com/photos/7170698/pexels-photo-7170698.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'A lone pilot navigates the edge of a dying galaxy in search of a habitable world, confronting memories of a home she can never return to.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
  {
    id: 'mock-2',
    title: 'Midnight Heist',
    genre: 'Thriller',
    duration: '1h 52m',
    image: 'https://images.pexels.com/photos/12810653/pexels-photo-12810653.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'A crew of strangers assembles for one impossible robbery, only to discover the real prize is the secret they all share.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
  {
    id: 'mock-3',
    title: 'The Last Cartographer',
    genre: 'Adventure',
    duration: '2h 06m',
    image: 'https://images.pexels.com/photos/13971537/pexels-photo-13971537.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'An aging mapmaker embarks on a final expedition to chart a river that appears on no modern map.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
  {
    id: 'mock-4',
    title: 'Echoes of Tomorrow',
    genre: 'Drama',
    duration: '2h 11m',
    image: 'https://images.pexels.com/photos/36587441/pexels-photo-36587441.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'A composer receives messages from her future self, each one revealing a melody she has not yet written.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
  {
    id: 'mock-5',
    title: 'Ironwood',
    genre: 'Action',
    duration: '2h 03m',
    image: 'https://images.pexels.com/photos/4334850/pexels-photo-4334850.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'A retired bodyguard returns to the city he swore never to revisit when the daughter of an old friend goes missing.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
  {
    id: 'mock-6',
    title: 'Paper Lanterns',
    genre: 'Romance',
    duration: '1h 47m',
    image: 'https://images.pexels.com/photos/8108661/pexels-photo-8108661.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
    desc: 'Two strangers meet during a lantern festival and spend one night trying to make a lifetime fit into a few hours.',
    createdAt: FIXED_DATE,
    updatedAt: FIXED_DATE,
  },
];

const REQUEST_TIMEOUT = 5000;

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      ...options,
    });
    if (!res.ok) {
      let message = `Request failed (${res.status})`;
      try {
        const body = await res.json();
        if (body?.error) message = body.error;
      } catch {
        /* ignore */
      }
      throw new Error(message);
    }
    return res.json() as Promise<T>;
  } finally {
    clearTimeout(timeout);
  }
}

export const api = {
  listMovies: async (): Promise<Movie[]> => {
    try {
      return await request<Movie[]>('/movies');
    } catch {
      return MOCK_MOVIES;
    }
  },
  getMovie: async (id: string): Promise<Movie> => {
    try {
      return await request<Movie>(`/movies/${id}`);
    } catch {
      const mock = MOCK_MOVIES.find((m) => m.id === id);
      if (mock) return mock;
      throw new Error('Movie not found');
    }
  },
  createMovie: (data: Partial<Movie>) =>
    request<Movie>('/movies', { method: 'POST', body: JSON.stringify(data) }),
  updateMovie: (id: string, data: Partial<Movie>) =>
    request<Movie>(`/movies/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
  deleteMovie: (id: string) =>
    request<{ message: string }>(`/movies/${id}`, { method: 'DELETE' }),
};
