import { useState } from 'react';
import { AuthProvider } from '@/context/AuthContext';
import { BookingsProvider } from '@/context/BookingsContext';
import Navbar from '@/components/Navbar';
import AuthView from '@/components/AuthView';
import HomeView from '@/components/HomeView';
import MovieDetails from '@/components/MovieDetails';
import SeatSelection from '@/components/SeatSelection';
import Checkout from '@/components/Checkout';
import Dashboard from '@/components/Dashboard';
import AdminGate from '@/components/AdminGate';
import AdminDashboard from '@/components/AdminDashboard';
import type { View } from '@/lib/types';

function AppContent() {
  const [view, setView] = useState<View>({ name: 'home' });
  const [adminUnlocked, setAdminUnlocked] = useState(false);

  const navigate = (next: View) => {
    setView(next);
    window.scrollTo({ top: 0 });
  };

  const render = () => {
    switch (view.name) {
      case 'home':
        return <HomeView onNavigate={navigate} />;
      case 'details':
        return <MovieDetails movieId={view.movieId} onNavigate={navigate} />;
      case 'seats':
        return (
          <SeatSelection
            movieId={view.movieId}
            theater={view.theater}
            showtime={view.showtime}
            onNavigate={navigate}
          />
        );
      case 'checkout':
        return (
          <Checkout
            movieId={view.movieId}
            theater={view.theater}
            showtime={view.showtime}
            seats={view.seats}
            total={view.total}
            onNavigate={navigate}
          />
        );
      case 'dashboard':
        return <Dashboard onNavigate={navigate} />;
      case 'auth':
        return <AuthView onNavigate={navigate} />;
      case 'admin':
        return adminUnlocked ? (
          <AdminDashboard onExitAdmin={() => setAdminUnlocked(false)} />
        ) : (
          <AdminGate
            onSuccess={() => setAdminUnlocked(true)}
            onBack={() => navigate({ name: 'home' })}
          />
        );
      default:
        return <HomeView onNavigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Navbar view={view} onNavigate={navigate} />
      <main>{render()}</main>
      <footer className="border-t border-slate-800 mt-10">
        <div className="max-w-7xl mx-auto px-6 py-8 text-center text-sm text-slate-500">
          IMovies — cinema booking for the modern moviegoer
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BookingsProvider>
        <AppContent />
      </BookingsProvider>
    </AuthProvider>
  );
}
