import { useState, useCallback, createContext, useContext, type ReactNode } from 'react';
import type { Booking } from '@/lib/api';

interface BookingsContextValue {
  bookings: Booking[];
  addBooking: (booking: Booking) => void;
  cancelBooking: (id: string) => void;
}

const BookingsContext = createContext<BookingsContextValue | null>(null);

const STORAGE_KEY = 'imovies_bookings';

export function BookingsProvider({ children }: { children: ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? (JSON.parse(raw) as Booking[]) : [];
    } catch {
      return [];
    }
  });

  const persist = useCallback((next: Booking[]) => {
    setBookings(next);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  }, []);

  const addBooking = useCallback(
    (booking: Booking) => {
      persist([booking, ...bookings]);
    },
    [bookings, persist],
  );

  const cancelBooking = useCallback(
    (id: string) => {
      persist(bookings.filter((b) => b.id !== id));
    },
    [bookings, persist],
  );

  return (
    <BookingsContext.Provider value={{ bookings, addBooking, cancelBooking }}>
      {children}
    </BookingsContext.Provider>
  );
}

export function useBookings() {
  const ctx = useContext(BookingsContext);
  if (!ctx) throw new Error('useBookings must be used within BookingsProvider');
  return ctx;
}
