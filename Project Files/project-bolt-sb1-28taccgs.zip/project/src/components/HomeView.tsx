import { useEffect, useMemo, useState } from 'react';
import { Search, Loader2, Clapperboard } from 'lucide-react';
import { api, type Movie } from '@/lib/api';
import type { View } from '@/lib/types';

interface HomeViewProps {
  onNavigate: (view: View) => void;
}

export default function HomeView({ onNavigate }: HomeViewProps) {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState('');

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      const data = await api.listMovies();
      if (!active) return;
      setMovies(data);
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return movies;
    return movies.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        (m.genre ?? '').toLowerCase().includes(q) ||
        (m.desc ?? '').toLowerCase().includes(q),
    );
  }, [movies, query]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex flex-col gap-6 mb-10">
        <div className="flex items-center gap-3">
          <Clapperboard className="w-7 h-7 text-emerald-400" />
          <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">Now Showing</h1>
        </div>
        <div className="relative max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search movies or genres..."
            className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900 border border-slate-800 text-white placeholder-slate-500 focus:border-emerald-500 outline-none transition-colors"
          />
        </div>
      </div>

      {loading && (
        <div className="flex items-center justify-center py-24 text-slate-400">
          <Loader2 className="w-6 h-6 animate-spin mr-2" />
          Loading movies...
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="text-center py-24 text-slate-400">No movies match your search.</div>
      )}

      {!loading && filtered.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
          {filtered.map((movie) => (
            <button
              key={movie.id}
              onClick={() => onNavigate({ name: 'details', movieId: movie.id })}
              className="group text-left bg-slate-900 rounded-2xl overflow-hidden border border-slate-800 hover:border-emerald-500/50 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-emerald-500/10"
            >
              <div className="aspect-[2/3] overflow-hidden bg-slate-800">
                {movie.image ? (
                  <img
                    src={movie.image}
                    alt={movie.title}
                    loading="lazy"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-600">
                    <Clapperboard className="w-10 h-10" />
                  </div>
                )}
              </div>
              <div className="p-4">
                <h3 className="font-semibold text-white truncate group-hover:text-emerald-400 transition-colors">
                  {movie.title}
                </h3>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                  {movie.genre && <span className="px-2 py-0.5 rounded-full bg-slate-800">{movie.genre}</span>}
                  {movie.duration && <span>{movie.duration}</span>}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
