import { useEffect, useState } from 'react';
import { ArrowLeft, CheckCircle2, CreditCard, Loader2, Ticket } from 'lucide-react';
import { api, type Movie, type Booking } from '@/lib/api';
import { useBookings } from '@/context/BookingsContext';
import { useAuth } from '@/context/AuthContext';
import type { View } from '@/lib/types';

interface CheckoutProps {
  movieId: string;
  theater: string;
  showtime: string;
  seats: string[];
  total: number;
  onNavigate: (view: View) => void;
}

export default function Checkout({ movieId, theater, showtime, seats, total, onNavigate }: CheckoutProps) {
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const { addBooking } = useBookings();
  const { user } = useAuth();

  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const data = await api.getMovie(movieId);
        if (!active) return;
        setMovie(data);
      } catch {
        if (!active) return;
      }
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [movieId]);

  const confirm = () => {
    if (!movie) return;
    setSubmitting(true);
    const booking: Booking = {
      id: crypto.randomUUID(),
      movieId: movie.id,
      movieTitle: movie.title,
      movieImage: movie.image,
      theater,
      showtime,
      seats,
      total,
      date: new Date().toISOString(),
    };
    addBooking(booking);
    setSubmitting(false);
    setDone(true);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        Loading...
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-24 text-center text-rose-400">
        Movie not found.
      </div>
    );
  }

  if (done) {
    return (
      <div className="max-w-md mx-auto px-6 py-20 text-center">
        <div className="w-16 h-16 rounded-full bg-emerald-500/15 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-8 h-8 text-emerald-400" />
        </div>
        <h1 className="text-2xl font-bold text-white">Booking confirmed!</h1>
        <p className="text-slate-400 mt-2">
          {seats.length} seat{seats.length > 1 ? 's' : ''} for {movie.title} at {showtime}.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <button
            onClick={() => onNavigate({ name: 'dashboard' })}
            className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold transition-colors"
          >
            View my tickets
          </button>
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-medium transition-colors"
          >
            Browse more movies
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-10">
      <button
        onClick={() => onNavigate({ name: 'seats', movieId, theater, showtime })}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to seats
      </button>

      <h1 className="text-3xl font-bold text-white tracking-tight mb-8">Checkout</h1>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="flex gap-4 p-5 border-b border-slate-800">
          {movie.image && (
            <img src={movie.image} alt={movie.title} className="w-20 h-28 rounded-lg object-cover" />
          )}
          <div>
            <h2 className="text-xl font-bold text-white">{movie.title}</h2>
            {movie.genre && <p className="text-sm text-slate-400 mt-1">{movie.genre}</p>}
            <p className="text-sm text-slate-400 mt-2">
              {theater} • {showtime}
            </p>
          </div>
        </div>

        <div className="p-5 space-y-3">
          <Row label="Seats" value={seats.join(', ')} />
          <Row label="Price per seat" value={`$${10}`} />
          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <span className="text-white font-semibold">Total</span>
            <span className="text-2xl font-bold text-emerald-400">${total}</span>
          </div>
        </div>
      </div>

      {!user && (
        <p className="text-amber-400/90 text-sm mt-4 flex items-center gap-2">
          <Ticket className="w-4 h-4" />
          You're not signed in — this booking will be saved on this device only.
        </p>
      )}

      <button
        onClick={confirm}
        disabled={submitting}
        className="w-full mt-6 flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold py-3.5 rounded-xl transition-colors"
      >
        <CreditCard className="w-5 h-5" />
        {submitting ? 'Processing...' : `Pay $${total}`}
      </button>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-slate-400">{label}</span>
      <span className="text-white font-medium">{value}</span>
    </div>
  );
}
