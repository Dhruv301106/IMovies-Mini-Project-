import { useEffect, useState, type ReactNode } from 'react';
import { Film, Pencil, Plus, Shield, Trash2, Loader2, LogOut } from 'lucide-react';
import { api, type Movie, MOCK_MOVIES } from '@/lib/api';
import { Modal } from '@/components/AdminGate';

interface AdminDashboardProps {
  onExitAdmin: () => void;
}

const EMPTY_FORM = { title: '', genre: '', duration: '', image: '', desc: '' };

export default function AdminDashboard({ onExitAdmin }: AdminDashboardProps) {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const data = await api.listMovies();
      setMovies(data);
    } catch {
      setMovies(MOCK_MOVIES);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const openAdd = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setShowForm(true);
  };

  const openEdit = (movie: Movie) => {
    setEditingId(movie.id);
    setForm({
      title: movie.title,
      genre: movie.genre ?? '',
      duration: movie.duration ?? '',
      image: movie.image ?? '',
      desc: movie.desc ?? '',
    });
    setShowForm(true);
  };

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    setSaving(true);
    setError('');
    const payload = {
      title: form.title.trim(),
      genre: form.genre.trim(),
      duration: form.duration.trim(),
      image: form.image.trim(),
      desc: form.desc.trim(),
    };
    try {
      if (editingId) {
        await api.updateMovie(editingId, payload);
      } else {
        await api.createMovie(payload);
      }
      setShowForm(false);
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
    setSaving(false);
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this movie? This cannot be undone.')) return;
    try {
      await api.deleteMovie(id);
      await load();
    } catch (err) {
      setError((err as Error).message);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <Shield className="w-7 h-7 text-emerald-400" />
          <h1 className="text-3xl font-bold text-white tracking-tight">Admin Dashboard</h1>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={openAdd}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold transition-colors"
          >
            <Plus className="w-4 h-4" />
            Add Movie
          </button>
          <button
            onClick={onExitAdmin}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Exit
          </button>
        </div>
      </div>

      {error && (
        <div className="bg-rose-500/10 border border-rose-500/30 text-rose-400 rounded-xl px-4 py-3 mb-6 text-sm">
          {error}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-20 text-slate-400">
          <Loader2 className="w-6 h-6 animate-spin mr-2" />
          Loading movies...
        </div>
      ) : movies.length === 0 ? (
        <div className="text-center py-20 text-slate-400">
          <Film className="w-12 h-12 mx-auto mb-4 text-slate-700" />
          No movies yet. Add your first one.
        </div>
      ) : (
        <div className="space-y-3">
          {movies.map((movie) => (
            <div
              key={movie.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center gap-4"
            >
              {movie.image ? (
                <img src={movie.image} alt={movie.title} className="w-14 h-20 rounded-lg object-cover flex-shrink-0" />
              ) : (
                <div className="w-14 h-20 rounded-lg bg-slate-800 flex items-center justify-center flex-shrink-0">
                  <Film className="w-5 h-5 text-slate-600" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-white truncate">{movie.title}</h3>
                <p className="text-sm text-slate-400 truncate">
                  {[movie.genre, movie.duration].filter(Boolean).join(' • ')}
                </p>
                {movie.desc && (
                  <p className="text-sm text-slate-500 truncate mt-1">{movie.desc}</p>
                )}
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => openEdit(movie)}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  title="Edit"
                >
                  <Pencil className="w-4 h-4" />
                </button>
                <button
                  onClick={() => remove(movie.id)}
                  className="p-2 rounded-lg bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white transition-colors"
                  title="Delete"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <Modal title={editingId ? 'Edit Movie' : 'Add Movie'} onClose={() => setShowForm(false)}>
          <form onSubmit={save} className="space-y-4">
            <FormField label="Title" required>
              <input
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Movie title"
                className={inputCls}
              />
            </FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Genre">
                <input
                  value={form.genre}
                  onChange={(e) => setForm({ ...form, genre: e.target.value })}
                  placeholder="Sci-Fi"
                  className={inputCls}
                />
              </FormField>
              <FormField label="Duration">
                <input
                  value={form.duration}
                  onChange={(e) => setForm({ ...form, duration: e.target.value })}
                  placeholder="2h 15m"
                  className={inputCls}
                />
              </FormField>
            </div>
            <FormField label="Poster URL">
              <input
                value={form.image}
                onChange={(e) => setForm({ ...form, image: e.target.value })}
                placeholder="https://..."
                className={inputCls}
              />
            </FormField>
            <FormField label="Description">
              <textarea
                value={form.desc}
                onChange={(e) => setForm({ ...form, desc: e.target.value })}
                placeholder="Synopsis..."
                rows={3}
                className={`${inputCls} resize-none`}
              />
            </FormField>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold transition-colors"
              >
                {saving ? 'Saving...' : editingId ? 'Update' : 'Add'}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}

const inputCls =
  'w-full px-3.5 py-2.5 rounded-xl bg-slate-800/60 border border-slate-700 focus:border-emerald-500 text-white placeholder-slate-500 outline-none transition-colors';

function FormField({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium text-slate-400 mb-1.5">
        {label}
        {required && <span className="text-emerald-400"> *</span>}
      </span>
      {children}
    </label>
  );
}
