import { useMemo, useState } from 'react';
import { ArrowLeft, Armchair, Check } from 'lucide-react';
import { SEAT_PRICE, type View } from '@/lib/types';

interface SeatSelectionProps {
  movieId: string;
  theater: string;
  showtime: string;
  onNavigate: (view: View) => void;
}

const ROWS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
const COLS = 8;

function generateBooked(): Set<string> {
  const booked = new Set<string>();
  const total = ROWS.length * COLS;
  const target = Math.round(total * 0.3);
  while (booked.size < target) {
    const row = ROWS[Math.floor(Math.random() * ROWS.length)];
    const col = 1 + Math.floor(Math.random() * COLS);
    booked.add(`${row}${col}`);
  }
  return booked;
}

export default function SeatSelection({ movieId, theater, showtime, onNavigate }: SeatSelectionProps) {
  const [booked] = useState(() => generateBooked());
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const toggleSeat = (seat: string) => {
    if (booked.has(seat)) return;
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(seat)) next.delete(seat);
      else next.add(seat);
      return next;
    });
  };

  const selectedList = useMemo(
    () => Array.from(selected).sort((a, b) => a.localeCompare(b, undefined, { numeric: true })),
    [selected],
  );
  const total = selected.size * SEAT_PRICE;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <button
        onClick={() => onNavigate({ name: 'details', movieId })}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to movie
      </button>

      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-white tracking-tight">Select your seats</h1>
        <p className="text-slate-400 mt-2">
          {theater} • {showtime}
        </p>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-10">
        <div className="mb-8">
          <div className="h-2 rounded-full bg-gradient-to-r from-transparent via-emerald-500/60 to-transparent mb-2" />
          <p className="text-center text-xs text-slate-500 uppercase tracking-widest">Screen</p>
        </div>

        <div className="flex flex-col items-center gap-2.5">
          {ROWS.map((row) => (
            <div key={row} className="flex items-center gap-2.5">
              <span className="w-5 text-xs text-slate-500 text-center">{row}</span>
              {Array.from({ length: COLS }, (_, i) => {
                const col = i + 1;
                const seat = `${row}${col}`;
                const isBooked = booked.has(seat);
                const isSelected = selected.has(seat);
                return (
                  <button
                    key={seat}
                    disabled={isBooked}
                    onClick={() => toggleSeat(seat)}
                    title={seat}
                    className={`w-8 h-8 sm:w-9 sm:h-9 rounded-lg flex items-center justify-center transition-all ${
                      isBooked
                        ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                        : isSelected
                          ? 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
                          : 'bg-slate-700 hover:bg-slate-600 text-slate-300'
                    }`}
                  >
                    {isBooked ? (
                      <span className="text-[10px]">×</span>
                    ) : isSelected ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Armchair className="w-4 h-4" />
                    )}
                  </button>
                );
              })}
              <span className="w-5 text-xs text-slate-500 text-center">{row}</span>
            </div>
          ))}
        </div>

        <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-xs text-slate-400">
          <Legend color="bg-slate-700" label="Available" />
          <Legend color="bg-emerald-500" label="Selected" />
          <Legend color="bg-slate-800" label="Booked" />
        </div>
      </div>

      <div className="sticky bottom-0 mt-6 bg-slate-950/90 backdrop-blur border border-slate-800 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4">
        <div>
          <p className="text-xs text-slate-400">Selected seats</p>
          <p className="text-white font-medium">
            {selectedList.length > 0 ? selectedList.join(', ') : 'None yet'}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-400">Total</p>
          <p className="text-2xl font-bold text-emerald-400">${total}</p>
        </div>
        <button
          disabled={selected.size === 0}
          onClick={() =>
            onNavigate({
              name: 'checkout',
              movieId,
              theater,
              showtime,
              seats: selectedList,
              total,
            })
          }
          className="px-6 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:bg-slate-800 disabled:text-slate-500 text-slate-950 font-semibold transition-colors"
        >
          Continue
        </button>
      </div>
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`w-4 h-4 rounded ${color}`} />
      <span>{label}</span>
    </div>
  );
}
