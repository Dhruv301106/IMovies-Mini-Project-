import { useEffect, useState } from 'react';
import { ArrowLeft, Clock, Film, Loader2, MapPin } from 'lucide-react';
import { api, type Movie } from '@/lib/api';
import { THEATERS, SHOWTIMES, type View } from '@/lib/types';

interface MovieDetailsProps {
  movieId: string;
  onNavigate: (view: View) => void;
}

export default function MovieDetails({ movieId, onNavigate }: MovieDetailsProps) {
  const [movie, setMovie] = useState<Movie | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      try {
        const data = await api.getMovie(movieId);
        if (!active) return;
        setMovie(data);
      } catch {
        if (!active) return;
      }
      setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [movieId]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-400">
        <Loader2 className="w-6 h-6 animate-spin mr-2" />
        Loading...
      </div>
    );
  }

  if (!movie) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-24 text-center">
        <p className="text-slate-400 mb-4">Movie not found.</p>
        <button
          onClick={() => onNavigate({ name: 'home' })}
          className="text-emerald-400 hover:text-emerald-300 font-medium"
        >
          Back to movies
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10">
      <button
        onClick={() => onNavigate({ name: 'home' })}
        className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-8"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </button>

      <div className="grid md:grid-cols-[280px_1fr] gap-8">
        <div className="rounded-2xl overflow-hidden border border-slate-800 bg-slate-900">
          {movie.image ? (
            <img src={movie.image} alt={movie.title} className="w-full aspect-[2/3] object-cover" />
          ) : (
            <div className="w-full aspect-[2/3] flex items-center justify-center text-slate-600">
              <Film className="w-12 h-12" />
            </div>
          )}
        </div>

        <div className="flex flex-col">
          <h1 className="text-3xl sm:text-4xl font-bold text-white tracking-tight">{movie.title}</h1>
          <div className="flex flex-wrap items-center gap-3 mt-3 text-sm text-slate-400">
            {movie.genre && <span className="px-2.5 py-1 rounded-full bg-slate-800">{movie.genre}</span>}
            {movie.duration && (
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" /> {movie.duration}
              </span>
            )}
          </div>

          <h2 className="text-lg font-semibold text-white mt-6 mb-2">Synopsis</h2>
          <p className="text-slate-300 leading-relaxed">{movie.desc || 'No description available.'}</p>

          <div className="mt-8 space-y-6">
            {THEATERS.map((theater) => (
              <div key={theater} className="bg-slate-900 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center gap-2 text-white font-medium mb-4">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  {theater}
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {SHOWTIMES.map((showtime) => (
                    <button
                      key={showtime}
                      onClick={() =>
                        onNavigate({ name: 'seats', movieId: movie.id, theater, showtime })
                      }
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-slate-200 font-medium text-sm transition-colors"
                    >
                      {showtime}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
