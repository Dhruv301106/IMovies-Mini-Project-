import { type ReactNode } from 'react';
import { Film, Home as HomeIcon, LayoutDashboard, Shield, LogIn, LogOut, Ticket } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import type { View } from '@/lib/types';

interface NavbarProps {
  view: View;
  onNavigate: (view: View) => void;
}

export default function Navbar({ view, onNavigate }: NavbarProps) {
  const { user, logout } = useAuth();

  const navItem = (label: string, icon: ReactNode, target: View, active: boolean) => (
    <button
      onClick={() => onNavigate(target)}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
        active
          ? 'bg-emerald-500/15 text-emerald-400'
          : 'text-slate-300 hover:text-white hover:bg-slate-800'
      }`}
    >
      {icon}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-950/80 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        <button
          onClick={() => onNavigate({ name: 'home' })}
          className="flex items-center gap-2 text-white"
        >
          <div className="w-9 h-9 rounded-xl bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Film className="w-5 h-5 text-slate-950" />
          </div>
          <span className="text-lg font-bold tracking-tight">IMovies</span>
        </button>

        <nav className="flex items-center gap-1">
          {navItem('Home', <HomeIcon className="w-4 h-4" />, { name: 'home' }, view.name === 'home')}
          {navItem('Dashboard', <LayoutDashboard className="w-4 h-4" />, { name: 'dashboard' }, view.name === 'dashboard')}
          {navItem('Admin', <Shield className="w-4 h-4" />, { name: 'admin' }, view.name === 'admin')}
        </nav>

        <div className="flex items-center gap-3">
          {user ? (
            <>
              <div className="hidden sm:flex items-center gap-2 text-sm text-slate-300">
                <Ticket className="w-4 h-4 text-emerald-400" />
                <span>{user.name}</span>
              </div>
              <button
                onClick={() => {
                  logout();
                  onNavigate({ name: 'home' });
                }}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </>
          ) : (
            <button
              onClick={() => onNavigate({ name: 'auth' })}
              className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors"
            >
              <LogIn className="w-4 h-4" />
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
