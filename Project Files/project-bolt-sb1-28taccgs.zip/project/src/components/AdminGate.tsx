import { useState, type ReactNode } from 'react';
import { Lock, Shield, User, ArrowLeft, Loader2, X } from 'lucide-react';

interface AdminGateProps {
  onSuccess: () => void;
  onBack: () => void;
}

const ADMIN_USERNAME = 'whatever@admin';
const ADMIN_PASSWORD = 'whatever';

export default function AdminGate({ onSuccess, onBack }: AdminGateProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    setTimeout(() => {
      if (username.trim() === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
        onSuccess();
      } else {
        setError('Invalid admin credentials.');
      }
      setLoading(false);
    }, 400);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to home
        </button>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center mb-4 ring-1 ring-slate-700">
              <Shield className="w-7 h-7 text-emerald-400" />
            </div>
            <h1 className="text-2xl font-bold text-white">Admin Access</h1>
            <p className="text-slate-400 text-sm mt-1">Sign in to manage the movie catalog</p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <label className="block">
              <span className="block text-xs font-medium text-slate-400 mb-1.5">Username</span>
              <div className="flex items-center gap-3 px-3.5 py-3 rounded-xl bg-slate-800/60 border border-slate-700 focus-within:border-emerald-500 transition-colors">
                <User className="w-4 h-4 text-slate-400" />
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin username"
                  className="w-full bg-transparent text-white placeholder-slate-500 outline-none"
                />
              </div>
            </label>
            <label className="block">
              <span className="block text-xs font-medium text-slate-400 mb-1.5">Password</span>
              <div className="flex items-center gap-3 px-3.5 py-3 rounded-xl bg-slate-800/60 border border-slate-700 focus-within:border-emerald-500 transition-colors">
                <Lock className="w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-transparent text-white placeholder-slate-500 outline-none"
                />
              </div>
            </label>

            {error && <p className="text-rose-400 text-sm">{error}</p>}

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-60 text-slate-950 font-semibold py-3 rounded-xl transition-colors"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Enter Admin'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <h2 className="text-lg font-bold text-white">{title}</h2>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}
