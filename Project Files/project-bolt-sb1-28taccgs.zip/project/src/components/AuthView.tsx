import { useState } from 'react';
import { type ReactNode } from 'react';
import { Film, Mail, Lock, User, ArrowRight } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import type { View } from '@/lib/types';

interface AuthViewProps {
  onNavigate: (view: View) => void;
}

export default function AuthView({ onNavigate }: AuthViewProps) {
  const { login } = useAuth();
  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) {
      setError('Please enter email and password.');
      return;
    }
    if (mode === 'signup' && !name.trim()) {
      setError('Please enter your name.');
      return;
    }
    const displayName = mode === 'signup' ? name.trim() : email.split('@')[0];
    login({ name: displayName, email: email.trim() });
    onNavigate({ name: 'home' });
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 shadow-2xl">
          <div className="flex flex-col items-center mb-8">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500 flex items-center justify-center mb-4 shadow-lg shadow-emerald-500/20">
              <Film className="w-7 h-7 text-slate-950" />
            </div>
            <h1 className="text-2xl font-bold text-white">
              {mode === 'signin' ? 'Welcome back' : 'Create your account'}
            </h1>
            <p className="text-slate-400 text-sm mt-1">
              {mode === 'signin' ? 'Sign in to book and manage tickets' : 'Join IMovies to start booking'}
            </p>
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'signup' && (
              <Field icon={<User className="w-4 h-4" />} label="Name">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full bg-transparent text-white placeholder-slate-500 outline-none"
                />
              </Field>
            )}
            <Field icon={<Mail className="w-4 h-4" />} label="Email">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-transparent text-white placeholder-slate-500 outline-none"
              />
            </Field>
            <Field icon={<Lock className="w-4 h-4" />} label="Password">
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-transparent text-white placeholder-slate-500 outline-none"
              />
            </Field>

            {error && <p className="text-rose-400 text-sm">{error}</p>}

            <button
              type="submit"
              className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold py-3 rounded-xl transition-colors"
            >
              {mode === 'signin' ? 'Sign In' : 'Create Account'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="text-center text-sm text-slate-400 mt-6">
            {mode === 'signin' ? "Don't have an account? " : 'Already have an account? '}
            <button
              onClick={() => {
                setMode(mode === 'signin' ? 'signup' : 'signin');
                setError('');
              }}
              className="text-emerald-400 hover:text-emerald-300 font-medium"
            >
              {mode === 'signin' ? 'Sign up' : 'Sign in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({ icon, label, children }: { icon: ReactNode; label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium text-slate-400 mb-1.5">{label}</span>
      <div className="flex items-center gap-3 px-3.5 py-3 rounded-xl bg-slate-800/60 border border-slate-700 focus-within:border-emerald-500 transition-colors">
        <span className="text-slate-400">{icon}</span>
        {children}
      </div>
    </label>
  );
}
