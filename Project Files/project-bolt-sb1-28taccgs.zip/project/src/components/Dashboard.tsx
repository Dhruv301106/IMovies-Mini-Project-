import { Ticket, Trash2, Calendar, Clock, MapPin, Film } from 'lucide-react';
import { useBookings } from '@/context/BookingsContext';
import { useAuth } from '@/context/AuthContext';
import type { View } from '@/lib/types';

interface DashboardProps {
  onNavigate: (view: View) => void;
}

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { bookings, cancelBooking } = useBookings();
  const { user } = useAuth();

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10">
      <div className="flex items-center gap-3 mb-8">
        <Ticket className="w-7 h-7 text-emerald-400" />
        <h1 className="text-3xl font-bold text-white tracking-tight">My Tickets</h1>
      </div>

      {!user && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 mb-6 flex items-center justify-between gap-4">
          <p className="text-slate-300 text-sm">
            Sign in to keep your bookings synced across devices.
          </p>
          <button
            onClick={() => onNavigate({ name: 'auth' })}
            className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold text-sm transition-colors"
          >
            Sign In
          </button>
        </div>
      )}

      {bookings.length === 0 ? (
        <div className="text-center py-20">
          <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center mx-auto mb-5">
            <Film className="w-8 h-8 text-slate-600" />
          </div>
          <h2 className="text-xl font-semibold text-white">No bookings yet</h2>
          <p className="text-slate-400 mt-2">Browse movies and book your first ticket.</p>
          <button
            onClick={() => onNavigate({ name: 'home' })}
            className="mt-6 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold transition-colors"
          >
            Browse movies
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <div
              key={booking.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col sm:flex-row gap-4"
            >
              {booking.movieImage && (
                <img
                  src={booking.movieImage}
                  alt={booking.movieTitle}
                  className="w-full sm:w-24 h-36 sm:h-32 rounded-lg object-cover"
                />
              )}
              <div className="flex-1">
                <h3 className="text-lg font-bold text-white">{booking.movieTitle}</h3>
                <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-sm text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" /> {booking.theater}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" /> {booking.showtime}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(booking.date).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {booking.seats.map((seat) => (
                    <span
                      key={seat}
                      className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-xs font-medium"
                    >
                      {seat}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex sm:flex-col items-center sm:items-end justify-between gap-3 sm:justify-between">
                <span className="text-xl font-bold text-emerald-400">${booking.total}</span>
                <button
                  onClick={() => cancelBooking(booking.id)}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-rose-500/10 text-rose-400 hover:bg-rose-500 hover:text-white text-sm font-medium transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  Cancel Ticket
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
