import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.SERVER_PORT || 5000;
const MONGO_URI = process.env.MONGO_URI;

if (!MONGO_URI) {
  console.error('MONGO_URI is not set. Add it to your .env file.');
  process.exit(1);
}

app.use(cors());
app.use(express.json());

app.use((req, _res, next) => {
  if (req.body && typeof req.body === 'object') {
    delete req.body._id;
    delete req.body.id;
  }
  next();
});

const movieSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    genre: { type: String, default: '' },
    duration: { type: String, default: '' },
    image: { type: String, default: '' },
    desc: { type: String, default: '' },
  },
  { timestamps: true },
);

const Movie = mongoose.model('Movie', movieSchema);

function serialize(doc) {
  const obj = doc.toObject ? doc.toObject() : doc;
  const { _id, __v, ...rest } = obj;
  return { id: String(_id), ...rest };
}

const SEED_MOVIES = [
  {
    title: 'Nebula Drift',
    genre: 'Sci-Fi',
    duration: '2h 18m',
    image: 'https://images.pexels.com/photos/7135199/pexels-photo-7135199.jpeg',
    desc: 'A lone pilot navigates the edge of a dying galaxy in search of a habitable world, confronting memories of a home she can never return to.',
  },
  {
    title: 'Midnight Heist',
    genre: 'Thriller',
    duration: '1h 52m',
    image: 'https://images.pexels.com/photos/3754228/pexels-photo-3754228.jpeg',
    desc: 'A crew of strangers assemble for one impossible robbery, only to discover the real prize is the secret they all share.',
  },
  {
    title: 'The Last Cartographer',
    genre: 'Adventure',
    duration: '2h 06m',
    image: 'https://images.pexels.com/photos/1671325/pexels-photo-1671325.jpeg',
    desc: 'An aging mapmaker embarks on a final expedition to chart a river that appears on no modern map.',
  },
  {
    title: 'Echoes of Tomorrow',
    genre: 'Drama',
    duration: '2h 11m',
    image: 'https://images.pexels.com/photos/261327/pexels-photo-261327.jpeg',
    desc: 'A composer receives messages from her future self, each one revealing a melody she has not yet written.',
  },
  {
    title: 'Ironwood',
    genre: 'Action',
    duration: '2h 03m',
    image: 'https://images.pexels.com/photos/2102416/pexels-photo-2102416.jpeg',
    desc: 'A retired bodyguard returns to the city he swore never to revisit when the daughter of an old friend goes missing.',
  },
  {
    title: 'Paper Lanterns',
    genre: 'Romance',
    duration: '1h 47m',
    image: 'https://images.pexels.com/photos/1190297/pexels-photo-1190297.jpeg',
    desc: 'Two strangers meet during a lantern festival and spend one night trying to make a lifetime fit into a few hours.',
  },
];

async function seedIfEmpty() {
  const count = await Movie.countDocuments();
  if (count === 0) {
    await Movie.insertMany(SEED_MOVIES);
    console.log(`Seeded ${SEED_MOVIES.length} sample movies`);
  }
}

app.get('/api/movies', async (_req, res) => {
  try {
    const movies = await Movie.find().sort({ createdAt: -1 });
    res.json(movies.map(serialize));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/movies', async (req, res) => {
  try {
    const movie = await Movie.create(req.body);
    res.status(201).json(serialize(movie));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.put('/api/movies/:id', async (req, res) => {
  try {
    const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    res.json(serialize(movie));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/movies/:id', async (req, res) => {
  try {
    const movie = await Movie.findByIdAndDelete(req.params.id);
    if (!movie) return res.status(404).json({ error: 'Movie not found' });
    res.json({ message: 'Movie deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

mongoose
  .connect(MONGO_URI)
  .then(async () => {
    console.log('Connected to MongoDB');
    await seedIfEmpty();
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB connection error:', err.message);
    process.exit(1);
  });
